package com.accela.ConnectionCenter;

import com.accela.ConnectionCenter.shared.IConstants;

public class BroadcastFunctionClosedException extends Exception
{
	private static final long serialVersionUID = IConstants.SERIAL_VERSION_UID;
	
	public BroadcastFunctionClosedException()
	{
		super();
	}
	
	public BroadcastFunctionClosedException(String message)
	{
		super(message);
	}
	
	public BroadcastFunctionClosedException(Throwable cause)
	{
		super(cause);
	}
	
	public BroadcastFunctionClosedException(String message, Throwable cause)
	{
		super(message, cause);
	}

}
