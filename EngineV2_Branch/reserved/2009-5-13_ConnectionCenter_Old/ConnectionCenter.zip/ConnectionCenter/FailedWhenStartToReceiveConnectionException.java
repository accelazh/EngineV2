package com.accela.ConnectionCenter;

import com.accela.ConnectionCenter.shared.IConstants;

public class FailedWhenStartToReceiveConnectionException extends Exception
{
	private static final long serialVersionUID = IConstants.SERIAL_VERSION_UID;
	
	public FailedWhenStartToReceiveConnectionException()
	{
		super();
	}
	
	public FailedWhenStartToReceiveConnectionException(String message)
	{
		super(message);
	}
	
	public FailedWhenStartToReceiveConnectionException(Throwable cause)
	{
		super(cause);
	}
	
	public FailedWhenStartToReceiveConnectionException(String message, Throwable cause)
	{
		super(message, cause);
	}

}
