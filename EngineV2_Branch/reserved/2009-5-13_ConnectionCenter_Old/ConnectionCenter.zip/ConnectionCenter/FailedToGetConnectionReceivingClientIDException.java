package com.accela.ConnectionCenter;

import com.accela.ConnectionCenter.shared.IConstants;

public class FailedToGetConnectionReceivingClientIDException extends Exception
{
	private static final long serialVersionUID = IConstants.SERIAL_VERSION_UID;

	public FailedToGetConnectionReceivingClientIDException()
	{
		super();
	}

	public FailedToGetConnectionReceivingClientIDException(String message)
	{
		super(message);
	}

	public FailedToGetConnectionReceivingClientIDException(Throwable cause)
	{
		super(cause);
	}

	public FailedToGetConnectionReceivingClientIDException(String message,
			Throwable cause)
	{
		super(message, cause);
	}

}
