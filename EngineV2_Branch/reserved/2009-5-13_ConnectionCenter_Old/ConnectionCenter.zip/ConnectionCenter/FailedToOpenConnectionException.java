package com.accela.ConnectionCenter;

import com.accela.ConnectionCenter.shared.IConstants;

public class FailedToOpenConnectionException extends Exception
{
	private static final long serialVersionUID = IConstants.SERIAL_VERSION_UID;
	
	public FailedToOpenConnectionException()
	{
		super();
	}
	
	public FailedToOpenConnectionException(String message)
	{
		super(message);
	}
	
	public FailedToOpenConnectionException(Throwable cause)
	{
		super(cause);
	}
	
	public FailedToOpenConnectionException(String message, Throwable cause)
	{
		super(message, cause);
	}

}
