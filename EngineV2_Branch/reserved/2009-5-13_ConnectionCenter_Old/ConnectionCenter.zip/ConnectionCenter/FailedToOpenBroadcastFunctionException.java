package com.accela.ConnectionCenter;

import com.accela.ConnectionCenter.shared.IConstants;

public class FailedToOpenBroadcastFunctionException extends Exception
{
	private static final long serialVersionUID = IConstants.SERIAL_VERSION_UID;
	
	public FailedToOpenBroadcastFunctionException()
	{
		super();
	}
	
	public FailedToOpenBroadcastFunctionException(String message)
	{
		super(message);
	}
	
	public FailedToOpenBroadcastFunctionException(Throwable cause)
	{
		super(cause);
	}
	
	public FailedToOpenBroadcastFunctionException(String message, Throwable cause)
	{
		super(message, cause);
	}

}
