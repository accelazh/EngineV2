package com.accela.ConnectionCenter.broadcaster;

import com.accela.ConnectionCenter.shared.IConstants;

public class BroadcasterAlreadyOpenedException extends Exception
{
	private static final long serialVersionUID = IConstants.SERIAL_VERSION_UID;

	public BroadcasterAlreadyOpenedException()
	{
		super();
	}
	
	public BroadcasterAlreadyOpenedException(String message)
	{
		super(message);
	}
}
