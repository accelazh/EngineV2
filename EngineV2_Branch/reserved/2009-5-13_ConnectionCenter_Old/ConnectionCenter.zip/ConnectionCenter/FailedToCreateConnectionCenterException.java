package com.accela.ConnectionCenter;

import com.accela.ConnectionCenter.shared.IConstants;

public class FailedToCreateConnectionCenterException extends Exception
{
	private static final long serialVersionUID = IConstants.SERIAL_VERSION_UID;
	
	public FailedToCreateConnectionCenterException()
	{
		super();
	}
	
	public FailedToCreateConnectionCenterException(String message)
	{
		super(message);
	}
	
	public FailedToCreateConnectionCenterException(Throwable cause)
	{
		super(cause);
	}
	
	public FailedToCreateConnectionCenterException(String message, Throwable cause)
	{
		super(message, cause);
	}
}
