package com.accela.ConnectionCenter.connectionReceiver;

import com.accela.ConnectionCenter.shared.IConstants;

public class ConnectionReceiverClosedException extends Exception
{
	private static final long serialVersionUID = IConstants.SERIAL_VERSION_UID;

	public ConnectionReceiverClosedException()
	{
		super();
	}

	public ConnectionReceiverClosedException(String message)
	{
		super(message);
	}
	
}
