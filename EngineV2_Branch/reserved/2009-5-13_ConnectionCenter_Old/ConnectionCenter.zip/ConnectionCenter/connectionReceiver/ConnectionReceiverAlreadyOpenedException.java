package com.accela.ConnectionCenter.connectionReceiver;

import com.accela.ConnectionCenter.shared.IConstants;

public class ConnectionReceiverAlreadyOpenedException extends Exception
{
	private static final long serialVersionUID = IConstants.SERIAL_VERSION_UID;

	public ConnectionReceiverAlreadyOpenedException()
	{
		super();
	}
	
	public ConnectionReceiverAlreadyOpenedException(String message)
	{
		super(message);
	}
}
