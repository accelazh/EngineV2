package com.accela.ConnectionCenter.connectionReceiver;

import com.accela.ConnectionCenter.shared.IConstants;

public class FailedToGetSelfClientIDException extends Exception
{
	private static final long serialVersionUID = IConstants.SERIAL_VERSION_UID;

	public FailedToGetSelfClientIDException()
	{
		super();
	}

	public FailedToGetSelfClientIDException(String message)
	{
		super(message);
	}

	public FailedToGetSelfClientIDException(String message, Throwable cause)
	{
		super(message, cause);
	}

	public FailedToGetSelfClientIDException(Throwable cause)
	{
		super(cause);
	}

}
