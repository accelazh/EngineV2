package com.accela.ConnectionCenter;

import com.accela.ConnectionCenter.shared.IConstants;

public class ConnectionReceivingFunctionNotStartedException extends Exception
{
	private static final long serialVersionUID = IConstants.SERIAL_VERSION_UID;

	public ConnectionReceivingFunctionNotStartedException()
	{
		super();
	}

	public ConnectionReceivingFunctionNotStartedException(String message)
	{
		super(message);
	}

	public ConnectionReceivingFunctionNotStartedException(String message,
			Throwable cause)
	{
		super(message, cause);
	}

	public ConnectionReceivingFunctionNotStartedException(Throwable cause)
	{
		super(cause);
	}

}
