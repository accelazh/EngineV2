package com.accela.ConnectionCenter.util;

import java.util.concurrent.*;

/**
 * һ�����������еķ�װ��
 * û���������ޡ�
 * 
 *
 */
public class BlockingQueueWrap<T>
{
    LinkedBlockingQueue<T> queue;
	
	public BlockingQueueWrap()
	{
		queue=new LinkedBlockingQueue<T>();
	}
	
	/**
	 * Inserts the specified element at the tail of this queue.
	 * @param value the inserted element
	 * @throws InterruptedException 
	 *
	 * @throws InterruptedException 
	 * @throws NullPointerException - if the specified element is null
	 */
	public void enqueue(T value) throws InterruptedException
	{
		if(null==value)
		{
			throw new NullPointerException("value == null");
		}
		
		queue.put(value);
	}
	
	/**
	 * Retrieves and removes the head of this queue, 
	 * waiting if necessary until an element becomes available.
	 * 
     * @return the head of this queue
     * 
	 * @throws InterruptedException 
	 */
	public T dequeue() throws InterruptedException
	{
		return queue.take();
	}
	
	/**
     * Returns <tt>true</tt> if this queue contains no elements.
     *
     * @return <tt>true</tt> if this queue contains no elements
     */
	public boolean isEmpty()
	{
		return queue.isEmpty();
	}
	
	public void clear()
	{
		queue.clear();
	}
	
	public int size()
	{
		return queue.size();
	}
	


}
