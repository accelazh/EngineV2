package com.accela.ConnectionCenter;

import com.accela.ConnectionCenter.shared.IConstants;

public class FailedToCloseBroadcastFunctionException extends Exception
{
	private static final long serialVersionUID = IConstants.SERIAL_VERSION_UID;
	
	public FailedToCloseBroadcastFunctionException()
	{
		super();
	}
	
	public FailedToCloseBroadcastFunctionException(String message)
	{
		super(message);
	}
	
	public FailedToCloseBroadcastFunctionException(Throwable cause)
	{
		super(cause);
	}
	
	public FailedToCloseBroadcastFunctionException(String message, Throwable cause)
	{
		super(message, cause);
	}

}
