package com.accela.ConnectionCenter.connectionLauncher;

import com.accela.ConnectionCenter.shared.IConstants;

public class NullNewConnectionInfoException extends Exception
{
	private static final long serialVersionUID = IConstants.SERIAL_VERSION_UID;

	public NullNewConnectionInfoException()
	{
		super();
	}
	
	public NullNewConnectionInfoException(String message)
	{
		super(message);
	}

}
