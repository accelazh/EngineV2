package com.accela.ConnectionCenter;

import com.accela.ConnectionCenter.shared.IConstants;

public class BroadcastFunctionAlreadyOpenedException extends Exception
{
	private static final long serialVersionUID = IConstants.SERIAL_VERSION_UID;
	
	public BroadcastFunctionAlreadyOpenedException()
	{
		super();
	}
	
	public BroadcastFunctionAlreadyOpenedException(String message)
	{
		super(message);
	}
	
	public BroadcastFunctionAlreadyOpenedException(Throwable cause)
	{
		super(cause);
	}
	
	public BroadcastFunctionAlreadyOpenedException(String message, Throwable cause)
	{
		super(message, cause);
	}


}
