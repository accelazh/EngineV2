package com.accela.ConnectionCenter;

import com.accela.ConnectionCenter.shared.IConstants;

public class ConnectionCenterAlreadyShutDownException extends Exception
{
	private static final long serialVersionUID = IConstants.SERIAL_VERSION_UID;
	
	public ConnectionCenterAlreadyShutDownException()
	{
		super();
	}
	
	public ConnectionCenterAlreadyShutDownException(String message)
	{
		super(message);
	}
	
	public ConnectionCenterAlreadyShutDownException(Throwable cause)
	{
		super(cause);
	}
	
	public ConnectionCenterAlreadyShutDownException(String message, Throwable cause)
	{
		super(message, cause);
	}

}
