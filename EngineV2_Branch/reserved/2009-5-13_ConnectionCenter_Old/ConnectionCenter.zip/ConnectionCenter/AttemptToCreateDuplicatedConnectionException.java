package com.accela.ConnectionCenter;

import com.accela.ConnectionCenter.shared.IConstants;

/**
 * 
 * ����쳣��ʾ����ͼ��һ���Ѿ������ϵĿͻ������½�һ������
 *
 */
public class AttemptToCreateDuplicatedConnectionException extends Exception
{
	private static final long serialVersionUID = IConstants.SERIAL_VERSION_UID;
	
	public AttemptToCreateDuplicatedConnectionException()
	{
		super();
	}
	
	public AttemptToCreateDuplicatedConnectionException(String message)
	{
		super(message);
	}
	
	public AttemptToCreateDuplicatedConnectionException(Throwable cause)
	{
		super(cause);
	}
	
	public AttemptToCreateDuplicatedConnectionException(String message, Throwable cause)
	{
		super(message, cause);
	}

}
