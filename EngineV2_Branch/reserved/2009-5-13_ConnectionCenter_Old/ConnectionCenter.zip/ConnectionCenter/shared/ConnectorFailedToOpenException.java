package com.accela.ConnectionCenter.shared;


public class ConnectorFailedToOpenException extends Exception
{
	private static final long serialVersionUID = IConstants.SERIAL_VERSION_UID;

	public ConnectorFailedToOpenException()
	{
		super();
	}
	
	public ConnectorFailedToOpenException(String message)
	{
		super(message);
	}

}
