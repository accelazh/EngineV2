package com.accela.ConnectionCenter.shared;


public class IllegalClientIDException extends Exception
{
	private static final long serialVersionUID = IConstants.SERIAL_VERSION_UID;

	public IllegalClientIDException()
	{
		super();
	}
	
	public IllegalClientIDException(String message)
	{
		super(message);
	}

}
