package com.accela.ConnectionCenter.shared;



/**
 * RemotePackage�������ϴ��͵���Ϣ�ı�ʾ��ʽ��
 * ��װ��clientID��message��
 * 
 * RemotePackage�ǲ��ɱ���
 *
 * 
 */
public class RemotePackage
{
	private ClientID clientID;
	private Object message;
	
	public RemotePackage(ClientID clientID, Object message)
	{
		if(null==clientID)
		{
			throw new NullPointerException("clientID is null");
		}
		if(null==message)
		{
			throw new NullPointerException("message is null");
		}
		
		
		this.clientID=clientID;
		this.message=message;
	}

	public ClientID getClientID()
	{
		return clientID;
	}

	public Object getMessage()
	{
		return message;
	}
	
	public String toString()
	{
		String out="";
		out+="RemotePackage["
			+"clientID="+clientID.toString()
			+", message="+message.toString()+"]";
		return out;
	}
	

}
