package com.accela.ConnectionCenter.shared;

public class IllegalNewConnectionInfoException extends Exception
{
	private static final long serialVersionUID = IConstants.SERIAL_VERSION_UID;

	public IllegalNewConnectionInfoException()
	{
		super();
	}
	
	public IllegalNewConnectionInfoException(String message)
	{
		super(message);
	}

}
