package com.accela.ConnectionCenter;

import com.accela.ConnectionCenter.shared.IConstants;

public class FailedToShutDownConnectionCenterException extends Exception
{
	private static final long serialVersionUID = IConstants.SERIAL_VERSION_UID;
	
	public FailedToShutDownConnectionCenterException()
	{
		super();
	}
	
	public FailedToShutDownConnectionCenterException(String message)
	{
		super(message);
	}
	
	public FailedToShutDownConnectionCenterException(Throwable cause)
	{
		super(cause);
	}
	
	public FailedToShutDownConnectionCenterException(String message, Throwable cause)
	{
		super(message, cause);
	}

}
