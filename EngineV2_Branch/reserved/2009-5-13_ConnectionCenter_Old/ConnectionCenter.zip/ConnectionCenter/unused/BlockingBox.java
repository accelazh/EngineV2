package com.accela.ConnectionCenter.unused;

import java.util.concurrent.locks.*;

/**
 * ��һ����СΪ1������������ͬ��ע�ⲻ��װ��null
 * 
 */
public class BlockingBox<T>
{
	private T element=null;
	
	private ReentrantLock putLock=new ReentrantLock();
	
	private Condition full=putLock.newCondition();
	
	private ReentrantLock takeLock=new ReentrantLock();
	
	private Condition empty=takeLock.newCondition();
	
	public void put(T value) throws InterruptedException
	{
		if(null == value)
		{
			throw new NullPointerException();
		}
		
		putLock.lock();
		try
		{
			while(element!=null)
			{
				full.await();
			}
			
			element=value;
			
			empty.signalAll();
		}
		finally
		{
			putLock.unlock();
		}
	}
	
	public T take() throws InterruptedException
	{
		takeLock.lock();
		T value=null;
		try
		{
			while(null==element)
			{
				empty.await();
			}
			
			value=element;
			element=null;
			
			full.signalAll();
		}
		finally
		{
			takeLock.unlock();
		}
		
		return value;
	}
	

}
