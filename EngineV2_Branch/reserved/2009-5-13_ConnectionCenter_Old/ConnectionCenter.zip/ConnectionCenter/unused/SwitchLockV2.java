package com.accela.ConnectionCenter.unused;

import java.util.concurrent.locks.ReentrantLock;

import com.accela.ConnectionCenter.util.HashMapWrap;

/**
 * 
 * ���˵���μ�SwitchLock������δ��
 * 
 * ������ʲôbug
 * 
 */
public class SwitchLockV2
{
	private HashMapWrap<Thread, ThreadCount> recordedThreads = new HashMapWrap<Thread, ThreadCount>();

	private ReentrantLock lock = new ReentrantLock();

	public void lockSwitch()
	{
		lock.lock();
		driveOutThreads();
	}

	private void driveOutThreads()
	{
		for (Thread t : recordedThreads.keyArray(new Thread[0]))
		{
			t.interrupt();
		}
	}

	public void unlockSwitch()
	{
		lock.unlock();
	}

	public void lockMethod()
	{
		lock.lock();
		try
		{
			recordThread();
		} finally
		{
			lock.unlock();
		}
	}

	public void unlockMethod()
	{
		disrecordThread();
	}

	private void recordThread()
	{
		Thread t = Thread.currentThread();
		ThreadCount count = recordedThreads.get(t);
		if (null == count)
		{
			recordedThreads.put(t, new ThreadCount(1));
		} else
		{
			count.increaseCount();
		}
	}

	private void disrecordThread()
	{
		Thread t = Thread.currentThread();
		ThreadCount count = recordedThreads.get(t);

		assert (count != null);
		if (null == count)
		{
			throw new IllegalStateException("illegal thread count");
		}

		count.decreaseCount();
		if (count.getCount() <= 0)
		{
			recordedThreads.remove(t);
		}

	}

	/**
	 * 
	 * ������¼һ���߳��������Ĵ���
	 * 
	 */
	private class ThreadCount
	{
		private int count = 0;

		public ThreadCount()
		{
			this(0);
		}

		public ThreadCount(int count)
		{
			if (count < 0)
			{
				throw new IllegalArgumentException("count should be nonnegtive");
			}
			this.count = count;
		}

		public void increaseCount()
		{
			count++;
		}

		public void decreaseCount()
		{
			count--;
			if (count < 0)
			{
				count = 0;
			}
		}

		public int getCount()
		{
			return count;
		}
	}

}
